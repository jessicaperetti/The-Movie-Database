﻿
//When the document is ready, it loads the function for the submit button, and popup function. 
$(document).ready(function () {
    $("#reset").click(function(e){
	location.reload();
      });
    //Submit button that calls the search database function.
    $("#submit").click(function (e) {
        var validate = Validate();
        $("#message").html(validate);
        if (validate.length == 0) {
            SearchDatabase(1);
        }
    });

      //Click on result title, brings up popup giving the overview, title, poster and popularity of selected film.
      $("#message").on('click', '.result', function()  {
        
	var resourceId = $(this).attr("resourceId");
	$.ajax({
                    url: "https://api.themoviedb.org/3/movie/" + resourceId + "?language=en-US",
                    data: {
                        api_key: "3c7865c88cb4a489f302bcf851e514c8"
                    },
                    dataType: 'json',
                    success: function (result, status, xhr) {
                      
			var title = result["title"];
                        var image = result["poster_path"] == null ? "Image/no-image.png" : " http://image.tmdb.org/t/p/w150/" + result["poster_path"];
                        var overview = result["overview"] == null ? "No information available" : result["overview"];
			var Close = "<br><br><p>Press Escape to Close</p>";

                        var resultHtml = "<p class = \"text-center\">" + title+ "<p class=\"text-center\"><img src=\"" + image + "\"/></p><p>" + overview + "</p>";
                        resultHtml += "<p>Release Date: " + result["release_date"] + "</p><p>Popularity: " + result["popularity"] + "";
			
                         $(".wp-content").html("");
			 $(".wp-content").append(resultHtml);
			 $(".wp-content").append(Close);
		         $(".window-popup").show(300);
			
			

                    },
                    error: function (xhr, status, error) {
			$(".wp-content").html("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText);
                    }
			
                });
	
	
    });
 
   //Closes Popup when Escape is Pressed.
   
    $(document).keydown(function(event) { 
      if (event.keyCode == 27) { 
        $(".window-popup").fadeOut(500);
       
    } 
    });
    
    
    //Shows the images that are displayed in the results.
    $(document).ajaxStart(function () {
        $(".imageCenter").show();
    });

    //Hides the images 
    $(document).ajaxStop(function () {
        $(".imageCenter").hide();
    });

     
    //Searches the The Movie Database using the title of the film. Brings up all related results. 
    function SearchDatabase(page) {
        $.ajax({
            url: "https://api.themoviedb.org/3/search/movie?language=en-US&query=" + $("#searchInput").val() + "&page=" + page + "&include_adult=false",
            data: { "api_key": "3c7865c88cb4a489f302bcf851e514c8" },
            dataType: "json",
            success: function (result, status, xhr) {
                var resultHtml = $("<div class=\"resultDiv\"><p><h1>Movie Titles</h1></p><br><br>");
                if(result["total_results"] == 0)
		{
		   alert("Oops! Oops! Looks like we couldn't find anything! Please enter in another Title");
		   
		}
		else{
                for (i = 0; i < result["results"].length; i++) {
 
                    var image = result["results"][i]["poster_path"] == null ? "Image/no-image.png" : "https://image.tmdb.org/t/p/w500/" + result["results"][i]["poster_path"];
 
                    resultHtml.append("<div class=\"result\" resourceId=\"" + result["results"][i]["id"] + "\">" + "<img src=\"" + image + "\" />" + "<p><a>" + result["results"][i]["title"] + "</a></p><br><br></div>")
                }
 
                resultHtml.append("</div>");
                $("#message").html(resultHtml);
 
                Paging(result["total_pages"]);
            }
	   },
            error: function (xhr, status, error) {
		var oops = "<p>Oops! Looks like we couldn't find anything! Please enter in another Title</p>";
                $(".wp-content").html("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText);
		$(".wp-content").append(oops);
		$(".wp-content").show(300);
            }
        });
    }
 
    //Ensures that the enter string exists.
    function Validate() {
        var errorMessage = "";
        if ($("#searchInput").val() == "") {
            errorMessage += "Oops! Please Enter some Text!";
            
        }
        return errorMessage;
        
    }
 
});